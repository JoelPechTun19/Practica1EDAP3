
import Nodo from './nodo.js';

export default class Catalogo {
  constructor() {
    this.raiz = null;
  }

  agregarLibro(libro) {
    this.raiz = this._agregarLibro(this.raiz, libro);
  }

  _agregarLibro(nodo, libro) {
    if (!nodo) {
      return new Nodo(libro);
    }

    if (libro.isbn < nodo.libro.isbn) {
      nodo.izquierda = this._agregarLibro(nodo.izquierda, libro);
    } else if (libro.isbn > nodo.libro.isbn) {
      nodo.derecha = this._agregarLibro(nodo.derecha, libro);
    }

    return nodo;
  }

  buscarLibro(isbn) {
    return this._buscarLibro(this.raiz, isbn);
  }

  _buscarLibro(nodo, isbn) {
    if (!nodo || nodo.libro.isbn === isbn) {
      return nodo ? nodo.libro : null;
    }

    if (isbn < nodo.libro.isbn) {
      return this._buscarLibro(nodo.izquierda, isbn);
    } else {
      return this._buscarLibro(nodo.derecha, isbn);
    }
  }

  eliminarLibro(isbn) {
    this.raiz = this._eliminarLibro(this.raiz, isbn);
  }

  _eliminarLibro(nodo, isbn) {
    if (!nodo) {
      return null;
    }

    if (isbn < nodo.libro.isbn) {
      nodo.izquierda = this._eliminarLibro(nodo.izquierda, isbn);
    } else if (isbn > nodo.libro.isbn) {
      nodo.derecha = this._eliminarLibro(nodo.derecha, isbn);
    } else {
      if (!nodo.izquierda) {
        return nodo.derecha;
      } else if (!nodo.derecha) {
        return nodo.izquierda;
      }

      nodo.libro = this._minValor(nodo.derecha);
      nodo.derecha = this._eliminarLibro(nodo.derecha, nodo.libro.isbn);
    }

    return nodo;
  }

  _minValor(nodo) {
    let actual = nodo;
    while (actual.izquierda) {
      actual = actual.izquierda;
    }
    return actual.libro;
  }

  mostrarCatalogo() {
    const catalogo = [];
    this._inOrder(this.raiz, catalogo);
    console.log(catalogo);
    return catalogo;
  }

  _inOrder(nodo, catalogo) {
    if (nodo) {
      this._inOrder(nodo.izquierda, catalogo);
      catalogo.push(nodo.libro);
      this._inOrder(nodo.derecha, catalogo);
    }
  }
}
