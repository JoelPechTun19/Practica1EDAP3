// main.js
import Libro from './libro.js';
import Catalogo from './catalogo.js';

const catalogo = new Catalogo();

function agregarLibro() {
    const isbnInput = document.getElementById('isbn');
    const titulo = document.getElementById('titulo').value;
    const autor = document.getElementById('autor').value;
  
    const isbn = isbnInput.value;
  
    // Verificar si el ISBN contiene solo números
    if (!/^\d+$/.test(isbn)) {
      alert('El ISBN debe contener solo números.');
      return;
    }
  
    // Verificar si el ISBN ya existe en el catálogo
    if (catalogo.buscarLibro(isbn)) {
      alert('Ya existe un libro con ese ISBN.');
      return;
    }
  
    const nuevoLibro = new Libro(isbn, titulo, autor);
    catalogo.agregarLibro(nuevoLibro);
  
    // Limpiar los campos del formulario
    isbnInput.value = '';
    document.getElementById('titulo').value = '';
    document.getElementById('autor').value = '';
  }

function buscarLibro() {
  const isbn = document.getElementById('buscarIsbn').value;
  const resultado = catalogo.buscarLibro(isbn);

  if (resultado) {
    alert(`Libro encontrado: ${JSON.stringify(resultado)}`);
  } else {
    alert('Libro no encontrado');
  }
}

function eliminarLibro() {
  const isbn = document.getElementById('eliminarIsbn').value;
  catalogo.eliminarLibro(isbn);
}

function mostrarCatalogo() {
  const catalogoElement = document.getElementById('catalogo');
  catalogoElement.innerHTML = '';

  const libros = catalogo.mostrarCatalogo();
  libros.forEach(libro => {
    const li = document.createElement('li');
    li.textContent = `Titulo: ${libro.titulo} - Autor: ${libro.autor} - ISBN: ${libro.isbn}`;
    catalogoElement.appendChild(li);
  });
}

document.getElementById('agregarBtn').addEventListener('click', agregarLibro);
document.getElementById('buscarBtn').addEventListener('click', buscarLibro);
document.getElementById('eliminarBtn').addEventListener('click', () => {
  eliminarLibro();
  mostrarCatalogo(); // Mostrar el catálogo después de eliminar un libro
});
document.getElementById('mostrarBtn').addEventListener('click', mostrarCatalogo);
