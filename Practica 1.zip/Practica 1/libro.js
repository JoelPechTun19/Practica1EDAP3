// libro.js
export default class Libro {
  constructor(isbn, titulo, autor) {
    this.isbn = isbn;
    this.titulo = titulo;
    this.autor = autor;
  }
}
