// nodo.js
export default class Nodo {
    constructor(libro) {
      this.libro = libro;
      this.izquierda = null;
      this.derecha = null;
    }
  }